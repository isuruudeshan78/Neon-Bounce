# NEON BOUNCE — Publishing Guide (Play Store + App Store)
Created by UDESHAN

## What you have
- `Neon Bounce.html` — the COMPLETE game (single file, works 100% offline after download).
- `store_assets/` — icons (192/512/1024), feature graphic, 3 screenshots.
- `manifest.json` — PWA config.
- The game already includes: 60 missions, country/language select (Sinhala, Hindi,
  Bengali, Spanish, Japanese, English), "Created by UDESHAN" branding, offline save.

## STEP 1 — Android (Google Play) — easiest, ~1 day
**Option A — PWABuilder (no coding, free):**
1. Host the game on any HTTPS host (Netlify / GitHub Pages / Vercel — all free).
2. Go to pwabuilder.com → enter your URL → it detects the manifest.
3. Download the **Android (Google Play / AAB)** package.
4. Create a Google Play Developer account ($25 one-time): play.google.com/console
5. Upload the AAB, add store assets from `store_assets/`, publish!

**Option B — Capacitor (native app):**
1. `npm install @capacitor/core @capacitor/cli`
2. `npx cap init "Neon Bounce" com.udeshan.neonbounce`
3. Put the HTML in `www/`, then `npx cap add android`
4. Open in Android Studio → Build → Generate Signed Bundle (AAB) → upload to Play Console.

## STEP 2 — iOS (App Store)
1. Apple Developer account: $99/year (developer.apple.com).
2. You need a Mac (or a cloud Mac service like MacInCloud) with Xcode.
3. `npx cap add ios` → open `ios/App/App.xcworkspace` in Xcode.
4. Set signing team, build, upload via App Store Connect.
5. Use `store_assets/icon-1024.png` as the App Store icon and screenshots.

## STEP 3 — Store listing text (copy-paste)

**Title:** Neon Bounce — 60 Missions

**Short description (80 chars):**
One-tap neon arcade! 60 missions, boss fights, 6 languages. 100% offline!

**Full description:**
🚀 Welcome to NEON BOUNCE — the most addictive one-tap arcade adventure!
Bounce through 60 exciting missions in a glowing neon world. Easy to learn,
impossible to put down!

🎮 HOW TO PLAY
• Tap the screen to bounce your ball
• Dodge the neon gates
• Collect stars in every mission
• Grab shields and power-ups
• Beat the boss levels and become the hero of the Neon World!

⭐ FEATURES
• 60 complete missions with increasing difficulty
• Star ratings on every mission (1–3 stars)
• Shield & power-up system
• Beautiful neon graphics with particle effects
• 6 languages: English, Sinhala, Hindi, Bengali, Spanish, Japanese
• 100% OFFLINE — no internet needed after download
• Saves your progress automatically
• Epic victory ending after mission 60!

👨‍💻 Created by UDESHAN 🇱🇰

Download now and see if you can complete all 60 missions! 🏆
